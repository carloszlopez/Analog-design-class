Version 4
SymbolType CELL
ARC Normal 24 16 56 -16 52 12 28 12
ARC Normal 48 16 80 -16 80 0 52 12
ARC Normal 0 16 32 -16 28 12 0 0
WINDOW 38 40 -32 Center 2
SYMATTR SpiceModel LPS3010-224_imp
SYMATTR Prefix X
SYMATTR ModelFile LPS3010.lib
PIN 80 0 NONE 0
PINATTR PinName port2
PINATTR SpiceOrder 2
PIN 0 0 NONE 0
PINATTR PinName port1
PINATTR SpiceOrder 1

